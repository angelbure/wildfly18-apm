#!/bin/sh

if [ "$(id -u)" = "0" ]; then
        echo "It was run as root account.please run it as a non-root account."
		echo "Exit the installer."
        exit
fi

sh bpm.sh -install
