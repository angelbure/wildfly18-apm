@ECHO OFF

bpm.cmd -install

pause