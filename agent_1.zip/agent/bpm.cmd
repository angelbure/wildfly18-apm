@ECHO OFF

if not "%JAVA_HOME%" == "" (
	echo JAVA_HOME=%JAVA_HOME%
	set "RUN_JAVA=%JAVA_HOME%\bin\java"
) else (
	set "RUN_JAVA=java"
)

if not "%ZENIUS_APM_AGENT_HOME%" == "" (
	echo ZENIUS_APM_AGENT_HOME=%ZENIUS_APM_AGENT_HOME%
) else (
	set "ZENIUS_APM_AGENT_HOME=."
)

set "CLASSPATH=%ZENIUS_APM_AGENT_HOME%\bpmcommon.jar"
set "CLASSPATH=%CLASSPATH%;%ZENIUS_APM_AGENT_HOME%\bpmcommon.jar"
set "CLASSPATH=%CLASSPATH%;%ZENIUS_APM_AGENT_HOME%\bpmboot.jar"
set "CLASSPATH=%CLASSPATH%;%ZENIUS_APM_AGENT_HOME%\bpmagent.jar"
set "CLASSPATH=%CLASSPATH%;%ZENIUS_APM_AGENT_HOME%\sujiboot.jar"
set "CLASSPATH=%CLASSPATH%;%ZENIUS_APM_AGENT_HOME%\suji.jar"

echo RUN_JAVA=%RUN_JAVA%
echo ZENIUS_APM_AGENT_HOME=%ZENIUS_APM_AGENT_HOME%
echo.
echo ---------------------------------
echo.

"%RUN_JAVA%" -cp  "%CLASSPATH%" com.brainzsquare.tools.Main %1

pause