#!/bin/sh

if [ "${JAVA_HOME}" != "" ]
then
	echo "> JAVA_HOME=${JAVA_HOME}"
	RUN_JAVA="${JAVA_HOME}/bin/java"
else
	RUN_JAVA="java"
fi

if [ "${ZENIUS_APM_AGENT_HOME}" != "" ]
then
	echo "> ZENIUS_APM_AGENT_HOME=${ZENIUS_APM_AGENT_HOME}"
else
	ZENIUS_APM_AGENT_HOME="."
fi

CLASSPATH="${ZENIUS_APM_AGENT_HOME}/bpmcommon.jar"
CLASSPATH="${CLASSPATH}:${ZENIUS_APM_AGENT_HOME}/bpmcommon.jar"
CLASSPATH="${CLASSPATH}:${ZENIUS_APM_AGENT_HOME}/bpmboot.jar"
CLASSPATH="${CLASSPATH}:${ZENIUS_APM_AGENT_HOME}/bpmagent.jar"
CLASSPATH="${CLASSPATH}:${ZENIUS_APM_AGENT_HOME}/sujiboot.jar"
CLASSPATH="${CLASSPATH}:${ZENIUS_APM_AGENT_HOME}/suji.jar"

echo "> RUN_JAVA=${RUN_JAVA}"
echo "> ZENIUS_APM_AGENT_HOME=${ZENIUS_APM_AGENT_HOME}"
echo
echo "---------------------------------- "
echo

$RUN_JAVA -cp "${CLASSPATH}" com.brainzsquare.tools.Main $1
