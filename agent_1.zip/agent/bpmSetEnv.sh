DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
export BPM_OPTS="-verbose:class -javaagent:$DIR/sujiboot.jar=$DIR"
