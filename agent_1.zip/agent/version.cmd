@ECHO OFF

bpm.cmd -version

pause