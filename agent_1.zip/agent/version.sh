#!/bin/sh

sh bpm.sh -version